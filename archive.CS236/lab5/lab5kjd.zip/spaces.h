int rh = 0;
bool debug = false;

string spaces()
{
	string spaces =  "";
	for(int i = 0; i<rh; i++)
	{
		spaces+=" ";
	}
	
	return spaces;
}
