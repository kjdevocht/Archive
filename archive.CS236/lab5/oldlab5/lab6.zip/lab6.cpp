/* CS 236 LAB 6 lab2 Kevin DeVocht*/
#include <fstream>
#include <algorithm>
#include <string>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <ctype.h>
#include <stdio.h>
#include <math.h>
#include "Database.h"


using namespace std;





int main(int argc, char *argv[])
{
	//Function Variables
	Database datalogDB(argv[1], argv[2]);	
}
