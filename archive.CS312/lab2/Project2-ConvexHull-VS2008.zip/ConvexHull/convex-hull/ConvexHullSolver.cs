using System;
using System.Collections.Generic;
using System.Text;

namespace _2_convex_hull
{
    class ConvexHullSolver
    {
        public void Solve(System.Drawing.Graphics g, List<System.Drawing.PointF> pointList)
        {
            // Insert your code here.

            throw new Exception("The method or operation is not implemented.");
        }
    }
}
