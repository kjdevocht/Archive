package shared.definitions;

public enum PieceType
{
	
	ROAD, SETTLEMENT, CITY, ROBBER
}
