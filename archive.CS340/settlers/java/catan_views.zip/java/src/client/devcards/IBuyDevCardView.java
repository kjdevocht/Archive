package client.devcards;

import client.base.*;

/**
 * "Buy dev card" view interface
 */
public interface IBuyDevCardView extends IOverlayView
{   
	
	// EMPTY
}
